import React, { useState } from "react";
import "./service.css";

const Contact = () => {
  const [Data, setData] = useState({
    fullName: "",
    phone: "",
    email: "",
    msg: ""
  });

  const inputEvent = (event) => {
    const { name, value } = event.target;

    setData((pre) => {
      return {
        ...pre,
        [name]: value
      };
    });
  };
  const formSubmit = (e) => {
    e.preventDefault();

    alert(`My fullName is ${Data.fullName} and ${Data.phone} is my number
    and my Email address is ${Data.email}. this is my advise for you => ${Data.msg}`);
  };

  return (
    <>
      <div className="main-div">
        <div className="heading">
          <h1>Our Services</h1>
        </div>

        <div className="mainInput">
          <form onSubmit={formSubmit}>
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">
                FullName
              </label>
              <input
                name="fullName"
                value={Data.fullName}
                onChange={inputEvent}
                type="text"
                class="form-control"
                id="exampleFormControlInput1"
                placeholder="Enter your fullname"
              />
            </div>
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">
                Phone
              </label>
              <input
                name="phone"
                value={Data.phone}
                onChange={inputEvent}
                type="Number"
                class="form-control"
                id="exampleFormControlInput1"
                placeholder="Enter your mobilenumber"
              />
            </div>
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">
                Email address
              </label>
              <input
                name="email"
                value={Data.email}
                onChange={inputEvent}
                type="email"
                class="form-control"
                id="exampleFormControlInput1"
                placeholder="Enter your Email"
              />
            </div>
            <div class="mb-3">
              <label for="exampleFormControlTextarea1" class="form-label">
                Message
              </label>
              <textarea
                name="msg"
                value={Data.msg}
                onChange={inputEvent}
                class="form-control"
                id="exampleFormControlTextarea1"
                rows="3"
                placeholder="Share your thought width us"
              ></textarea>
              <div class="col-12  text_cewnter">
                <button class=" mt-3  btn btn-primary   " type="submit">
                  Submit form
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default Contact;
