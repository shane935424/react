import React from "react";

import "./service.css";
import Sdata from "./Sdata";

import Card from "./Card";

const Service = () => {
  return (
    <>
      <div className="mian_Card">
        <div className="heading">
          <h1>Our Services</h1>
        </div>
        <div className="cards">
          {Sdata.map((val, index) => {
            return (
              <>
                <Card key={index} imgsrc={val.imgsrc} title={val.title} />
              </>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default Service;
