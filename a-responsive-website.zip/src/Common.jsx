import React from "react";

import { NavLink } from "react-router-dom";

const Common = (props) => {
  return (
    <>
      <section className="main" id="main_section">
        <div className="main_div">
          <div className="logo2">
            <div className="navlinks">
              <h1>
                {props.name}
                <strong className="brand-name"> AlamTechnical</strong>
              </h1>
              <h3>We are the Team of Talented Developer</h3>
              <div className="mt-3">
                <NavLink to={props.visit} className="btn  getstarted">
                  {props.btname}
                </NavLink>
              </div>
            </div>

            <div className="for-img">
              <img
                className="img-fluid animated"
                src={props.imgsrc}
                alt="this is "
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Common;
