import web from "../src/images/1.jpg";
import App from "../src/images/2.jpg";
import Java from "../src/images/3.jpg";
import fullStact from "../src/images/4.jpg";
import python from "../src/images/5.jpg";
import jquery from "../src/images/6.jpg";

const Sdata = [
  {
    title: "Web development",
    imgsrc: web
  },
  {
    title: "App development ",
    imgsrc: App
  },
  {
    title: "Java development ",
    imgsrc: Java
  },
  {
    title: "Fullstact development ",
    imgsrc: fullStact
  },
  {
    title: "Phython development ",
    imgsrc: python
  },
  {
    title: "jquery development ",
    imgsrc: jquery
  }
];

export default Sdata;
