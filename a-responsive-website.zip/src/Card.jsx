import React from "react";

const Card = (props) => {
  return (
    <>
      <div className="image-div">
        <img className="service_image" src={props.imgsrc} alt="fdfd" />
        <div className="title">
          <h2 style={{ fontSize: "2rem" }}>{props.title}</h2>
          <p style={{ fontSize: "1rem" }}>This will be our discription</p>
          <button className="btn goSome">Go SomeWhere</button>
        </div>
      </div>
    </>
  );
};
export default Card;
