import React from "react";
import { NavLink } from "react-router-dom";

const Navbar = () => {
  return (
    <>
      <div className="main_div">
        <div className="logo">
          <NavLink to="/">Alam Teachnical</NavLink>
        </div>

        <div className="navlinks">
          <NavLink activeClassName="active" to="/">
            Home
          </NavLink>
          <NavLink activeClassName="active" to="/Service">
            Service
          </NavLink>
          <NavLink activeClassName="active" to="/About">
            About
          </NavLink>
          <NavLink activeClassName="active" to="/Contact">
            Contact
          </NavLink>
        </div>
      </div>
    </>
  );
};

export default Navbar;
