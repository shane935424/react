import React from "react";
import Common from "./Common";
import Web from "../src/images/home33.png";

const About = () => {
  return (
    <>
      <Common
        name="This is our About Page"
        imgsrc={Web}
        visit="/Contact"
        btname="Contact us"
      />
    </>
  );
};
export default About;
