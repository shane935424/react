import React from "react";
import Web from "../src/images/home33.png";
import Common from "./Common";

const Home = () => {
  return (
    <>
      <Common
        name="Grow your buisness with"
        imgsrc={Web}
        visit="/Service"
        btname="Get Stated"
      />
    </>
  );
};

export default Home;
